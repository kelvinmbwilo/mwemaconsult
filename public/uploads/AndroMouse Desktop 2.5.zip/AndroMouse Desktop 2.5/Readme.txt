
AndroMouse Server V 2.5
_______________________________________________

Thank you for your interest in AndroMouse.

AndroMouse lets you convert your Android device into wireless mouse, keyboard and more. AndroMouse uses Google voice recognition for accurate and fast voice recognition that you can transfer to your computer.

AndroMouse connects to your computer using your existing wireless connection(Windows/Mac/Linux). If your computer is equipped with Bluetooth or if you have a bluetooth dongle, you don't need wifi(Windows/Mac unfortunately Bluetooth on Linux is not currently supported and I am working on it).
It also features advanced keyboard including function and special keys.

Many new features are added on the new version.

Please visit http://andromouse.com for a quick tutorial. Post your question and issues on the website or send an email to info@iandrobot.net
Based on your comments and recommendations, we will be updating AndroMouse frequently.


Again thank you for your consideration. Have fun with AndroMouse. And please don't forget to give five star rating, this will encourage us.

Like us on FaceBook: http://www.facebook.com/pages/iAndrobotnet/116454748422995

Note: To use AndroMouse desktop server, you need to have Java installed in your computer. Please download it from: http://java.com/en/download/index.jsp
